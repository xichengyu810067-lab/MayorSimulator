# Building and Blueprint UI Icon Prompt Set

Generated with the built-in image generation tool on 2026-07-22. All icons referenced the existing buildings, blueprint, treasury, and city hall icons for style continuity.

Shared direction: square game UI icon; cute children's storybook civic-management game; thick dark-brown outline; warm saturated colors; soft hand-painted shading; compact readable silhouette; subtle golden accents; centered subject; generous safe margins; solid pure `#ff00ff` chroma-key background; no text, logo, watermark, border, frame, or extra scenery.

## Building groups

- Housing: two cozy homes and a small apartment building.
- Economy: storefront, clean compact factory, coins and upward sparkle.
- Community: park tree, open book and small clinic heart/cross.
- Safe mobility: city bus, curved road, protective shield and beacon.
- Utilities: water drop, lightning bolt, recycling arrows and utility tower.
- Civic: city hall, courthouse scales and oversight magnifying glass.

## Blueprint controls

- Material: wood, brick, steel and eco-composite samples.
- Size: small, medium and large building silhouettes with measuring arrow.
- Floors: three-storey cutaway building with an upward arrow.
- Workers: two construction workers with wrench and rolled plan.
- Decoration: flower planter, civic flag and colorful window trim.
